# Nightcore Floating does not require custom ProGuard rules for debug builds.
