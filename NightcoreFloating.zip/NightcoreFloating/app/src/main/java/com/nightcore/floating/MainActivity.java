package com.nightcore.floating;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 100;
    private static final int REQ_CAPTURE = 101;
    private MediaProjectionManager mpm;
    private ObjectAnimator glowAnim;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        View glow = findViewById(R.id.glow);
        glowAnim = ObjectAnimator.ofPropertyValuesHolder(glow,
                PropertyValuesHolder.ofFloat("scaleX", 0.85f, 1.12f),
                PropertyValuesHolder.ofFloat("scaleY", 0.85f, 1.12f),
                PropertyValuesHolder.ofFloat("alpha", 1f, 0.35f));
        glowAnim.setDuration(1800);
        glowAnim.setRepeatCount(ObjectAnimator.INFINITE);
        glowAnim.setRepeatMode(ObjectAnimator.REVERSE);
        glowAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        glowAnim.start();

        View start = findViewById(R.id.btnStart);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQ_OVERLAY);
            } else requestCapture();
        });
    }

    private void requestCapture() { startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY && Settings.canDrawOverlays(this)) requestCapture();
        else if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, FloatingService.class);
            svc.putExtra("code", res);
            svc.putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
            finish();
        }
    }

    @Override protected void onDestroy() {
        if (glowAnim != null) glowAnim.cancel();
        super.onDestroy();
    }
}
