package com.nightcore.floating;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.nio.ByteBuffer;

public class FloatingService extends Service {
    private WindowManager wm;
    private View bubbleView, menuView, cropView;
    private WindowManager.LayoutParams bubbleParams, menuParams, cropParams;
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private int screenW, screenH, screenDpi;
    private FrameLayout cropContainer;
    private String mode = "ai";
    private final int baseWidth = 260, baseHeight = 180;
    private View webWindow;
    private WebView webView;
    private WindowManager.LayoutParams webParams;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels; screenH = dm.heightPixels; screenDpi = dm.densityDpi;
        startForeground(1, buildNotification());
        showBubble();
    }

    private Notification buildNotification() {
        String ch = "nc_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(ch, "Nightcore", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
        return new NotificationCompat.Builder(this, ch)
                .setContentTitle("Nightcore Floating")
                .setContentText("Aktif — tap bubble")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .build();
    }

    private void showBubble() {
        bubbleView = LayoutInflater.from(this).inflate(R.layout.bubble, null);
        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = Math.max(0, screenW - 90); bubbleParams.y = screenH / 2;
        wm.addView(bubbleView, bubbleParams);
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY; float tx, ty; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: initX=bubbleParams.x; initY=bubbleParams.y; tx=e.getRawX(); ty=e.getRawY(); moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(e.getRawX()-tx), dy=(int)(e.getRawY()-ty);
                        if (Math.abs(dx)>8 || Math.abs(dy)>8) moved=true;
                        bubbleParams.x=initX+dx; bubbleParams.y=initY+dy; wm.updateViewLayout(bubbleView,bubbleParams); return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) { animateBubble(); showMenu(); } else snapToEdge(); return true;
                    default: return false;
                }
            }
        });
    }

    private void animateBubble() {
        bubbleView.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction(() ->
                bubbleView.animate().scaleX(1f).scaleY(1f).setDuration(80).start()).start();
    }

    private void snapToEdge() {
        bubbleParams.x = bubbleParams.x < screenW / 2 ? -18 : screenW - 22;
        wm.updateViewLayout(bubbleView, bubbleParams);
    }

    private void showMenu() {
        if (menuView != null) { wm.removeView(menuView); menuView=null; }
        menuView = LayoutInflater.from(this).inflate(R.layout.menu, null);
        menuParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        menuParams.gravity = Gravity.TOP | Gravity.START;
        int menuX = bubbleParams.x < screenW/2 ? bubbleParams.x+60 : bubbleParams.x-210;
        menuParams.x = Math.max(8, Math.min(menuX, screenW-220));
        menuParams.y = Math.max(8, Math.min(bubbleParams.y, screenH-300));
        wm.addView(menuView, menuParams);
        menuView.findViewById(R.id.mGoogle).setOnClickListener(v->{mode="search";closeMenu();showCrop();});
        menuView.findViewById(R.id.mAI).setOnClickListener(v->{mode="ai";closeMenu();showCrop();});
        menuView.findViewById(R.id.mTranslate).setOnClickListener(v->{mode="translate";closeMenu();showCrop();});
        menuView.findViewById(R.id.mGallery).setOnClickListener(v->{closeMenu();Intent i=new Intent(Intent.ACTION_VIEW);i.setType("image/*");i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception ignored){}});
    }

    private void closeMenu(){if(menuView!=null){wm.removeView(menuView);menuView=null;}}

    private void showCrop() {
        if(cropView!=null)wm.removeView(cropView);
        cropView=LayoutInflater.from(this).inflate(R.layout.crop_overlay,null);
        cropContainer=cropView.findViewById(R.id.cropContainer);
        cropParams=new WindowManager.LayoutParams(screenW,screenH,getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        cropParams.gravity=Gravity.TOP|Gravity.START; wm.addView(cropView,cropParams);
        ViewGroup.LayoutParams lp=cropContainer.getLayoutParams();lp.width=baseWidth;lp.height=baseHeight;cropContainer.setLayoutParams(lp);
        cropContainer.setX((screenW-baseWidth)/2f);cropContainer.setY((screenH-baseHeight)/2f);
        cropContainer.setOnTouchListener(new View.OnTouchListener(){float downX,downY;float startX,startY;
            @Override public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=cropContainer.getX();startY=cropContainer.getY();return true;case MotionEvent.ACTION_MOVE:cropContainer.setX(startX+e.getRawX()-downX);cropContainer.setY(startY+e.getRawY()-downY);return true;default:return false;}}});
        ImageView handle=cropView.findViewById(R.id.resizeHandle);
        handle.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int startW,startH;
            @Override public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startW=cropContainer.getWidth();startH=cropContainer.getHeight();return true;case MotionEvent.ACTION_MOVE:int newW=Math.max(120,startW+(int)(e.getRawX()-downX));int newH=Math.max(80,startH+(int)(e.getRawY()-downY));ViewGroup.LayoutParams lp=cropContainer.getLayoutParams();lp.width=newW;lp.height=newH;cropContainer.setLayoutParams(lp);return true;default:return false;}}});
        cropView.findViewById(R.id.btnCancel).setOnClickListener(v->closeCrop());
        cropView.findViewById(R.id.btnConfirm).setOnClickListener(v->captureCrop());
    }

    private void closeCrop(){if(cropView!=null){wm.removeView(cropView);cropView=null;}}

    private void captureCrop(){
        if(projection==null){Toast.makeText(this,"Izin capture belum siap",Toast.LENGTH_SHORT).show();closeCrop();return;}
        final int left=Math.max(0,(int)cropContainer.getX()),top=Math.max(0,(int)cropContainer.getY());
        final int w=Math.min(cropContainer.getWidth(),screenW-left),h=Math.min(cropContainer.getHeight(),screenH-top);
        closeCrop();
        if(w<=0||h<=0)return;
        new Handler(Looper.getMainLooper()).postDelayed(()->startCapture(left,top,w,h),250);
    }

    private void startCapture(final int left,final int top,final int w,final int h){
        releaseCapture();
        try{
            reader=ImageReader.newInstance(screenW,screenH,PixelFormat.RGBA_8888,2);
            display=projection.createVirtualDisplay("nc",screenW,screenH,screenDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
            reader.setOnImageAvailableListener(r->{
                Image img=r.acquireLatestImage();
                if(img==null)return;
                Bitmap full=imageToBitmap(img);
                img.close();
                releaseCapture();
                Bitmap crop=Bitmap.createBitmap(full,left,top,w,h);
                if(crop!=full)full.recycle();
                runOcr(crop);
            },new Handler(Looper.getMainLooper()));
        }catch(Exception e){
            releaseCapture();
            Toast.makeText(this,"Capture gagal",Toast.LENGTH_SHORT).show();
        }
    }

    private void releaseCapture(){
        if(display!=null){display.release();display=null;}
        if(reader!=null){reader.close();reader=null;}
    }

    private Bitmap imageToBitmap(Image image){Image.Plane[] planes=image.getPlanes();ByteBuffer buffer=planes[0].getBuffer();int pixelStride=planes[0].getPixelStride();int rowStride=planes[0].getRowStride();int rowPadding=rowStride-pixelStride*screenW;Bitmap bmp=Bitmap.createBitmap(screenW+rowPadding/pixelStride,screenH,Bitmap.Config.ARGB_8888);bmp.copyPixelsFromBuffer(buffer);return Bitmap.createBitmap(bmp,0,0,screenW,screenH);}

    private void runOcr(Bitmap bmp){InputImage image=InputImage.fromBitmap(bmp,0);TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(result->{String text=result.getText().trim();bmp.recycle();if(text.isEmpty()){Toast.makeText(this,"Tidak ada teks terdeteksi",Toast.LENGTH_SHORT).show();return;}openTarget(text);}).addOnFailureListener(e->{bmp.recycle();Toast.makeText(this,"OCR gagal",Toast.LENGTH_SHORT).show();});}

    private void openTarget(String text){
        if(text.length()>1500)text=text.substring(0,1500);
        String url,title;
        switch(mode){
            case "search":
                url="https://www.google.com/search?q="+Uri.encode(text.replaceAll("\\s+"," "));
                title="Google Search";break;
            case "translate":
                url="https://translate.google.com/?sl=auto&tl=id&text="+Uri.encode(text);
                title="Google Translate";break;
            default:
                url="https://www.google.com/search?udm=50&q="+Uri.encode(text.replaceAll("\\s+"," "));
                title="Google AI Mode";break;
        }
        showWebWindow(url,title);
    }

    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void openExternal(String url){
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Tidak ada browser",Toast.LENGTH_SHORT).show();}
    }

    private void showWebWindow(final String url,String title){
        closeWeb();
        try{
            Context themed=new ContextThemeWrapper(this,R.style.Theme_Nightcore);
            webWindow=LayoutInflater.from(themed).inflate(R.layout.web_window,null);
            webView=webWindow.findViewById(R.id.webView);

            WebSettings st=webView.getSettings();
            st.setJavaScriptEnabled(true);
            st.setDomStorageEnabled(true);
            st.setUserAgentString(st.getUserAgentString().replace("; wv","").replace("Version/4.0 ",""));
            CookieManager cm=CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webView,true);
            webView.setWebViewClient(new WebViewClient(){
                @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                    String u=r.getUrl().toString();
                    return !(u.startsWith("http://")||u.startsWith("https://"));
                }
            });
            webView.setOnKeyListener((v,keyCode,ev)->{
                if(keyCode==KeyEvent.KEYCODE_BACK&&webView!=null&&webView.canGoBack()){
                    if(ev.getAction()==KeyEvent.ACTION_UP)webView.goBack();
                    return true;
                }
                return false;
            });

            ((TextView)webWindow.findViewById(R.id.webTitle)).setText(title);
            webWindow.findViewById(R.id.webClose).setOnClickListener(v->closeWeb());
            webWindow.findViewById(R.id.webBrowser).setOnClickListener(v->{
                String cur=(webView!=null&&webView.getUrl()!=null)?webView.getUrl():url;
                closeWeb();
                openExternal(cur);
            });

            int w=(int)(screenW*0.94f),h=(int)(screenH*0.6f);
            webParams=new WindowManager.LayoutParams(w,h,getOverlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            webParams.gravity=Gravity.TOP|Gravity.START;
            webParams.x=(screenW-w)/2;
            webParams.y=(int)(screenH*0.1f);
            webParams.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
            wm.addView(webWindow,webParams);

            webWindow.findViewById(R.id.webTitleBar).setOnTouchListener(new View.OnTouchListener(){
                int ix,iy;float tx,ty;
                @Override public boolean onTouch(View v,MotionEvent e){
                    switch(e.getAction()){
                        case MotionEvent.ACTION_DOWN:ix=webParams.x;iy=webParams.y;tx=e.getRawX();ty=e.getRawY();return true;
                        case MotionEvent.ACTION_MOVE:
                            webParams.x=ix+(int)(e.getRawX()-tx);
                            webParams.y=Math.max(0,iy+(int)(e.getRawY()-ty));
                            if(webWindow!=null)wm.updateViewLayout(webWindow,webParams);
                            return true;
                        default:return false;
                    }
                }
            });
            webWindow.findViewById(R.id.webResize).setOnTouchListener(new View.OnTouchListener(){
                int sw,sh;float tx,ty;
                @Override public boolean onTouch(View v,MotionEvent e){
                    switch(e.getAction()){
                        case MotionEvent.ACTION_DOWN:sw=webParams.width;sh=webParams.height;tx=e.getRawX();ty=e.getRawY();return true;
                        case MotionEvent.ACTION_MOVE:
                            webParams.width=Math.max(dp(200),Math.min(screenW,sw+(int)(e.getRawX()-tx)));
                            webParams.height=Math.max(dp(200),Math.min(screenH,sh+(int)(e.getRawY()-ty)));
                            if(webWindow!=null)wm.updateViewLayout(webWindow,webParams);
                            return true;
                        default:return false;
                    }
                }
            });

            webView.loadUrl(url);
        }catch(Exception e){
            closeWeb();
            openExternal(url);
        }
    }

    private void closeWeb(){
        if(webWindow!=null){try{wm.removeView(webWindow);}catch(Exception ignored){}webWindow=null;}
        if(webView!=null){try{webView.stopLoading();webView.destroy();}catch(Exception ignored){}webView=null;}
    }

    private int getOverlayType(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}

    @Override public int onStartCommand(Intent intent,int flags,int startId){if(intent!=null&&intent.hasExtra("data")){int code=intent.getIntExtra("code",0);Intent data=intent.getParcelableExtra("data");MediaProjectionManager mpm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);if(data!=null)projection=mpm.getMediaProjection(code,data);}return START_STICKY;}

    @Override public void onDestroy(){closeWeb();if(bubbleView!=null)wm.removeView(bubbleView);if(menuView!=null)wm.removeView(menuView);if(cropView!=null)wm.removeView(cropView);if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();super.onDestroy();}
}
